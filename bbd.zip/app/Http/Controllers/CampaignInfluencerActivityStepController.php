<?php

namespace App\Http\Controllers;

use App\Models\CampaignInfluencerActivityStep;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CampaignInfluencerActivityStepController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CampaignInfluencerActivityStep  $campaignInfluencerActivityStep
     * @return \Illuminate\Http\Response
     */
    public function show(CampaignInfluencerActivityStep $campaignInfluencerActivityStep)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CampaignInfluencerActivityStep  $campaignInfluencerActivityStep
     * @return \Illuminate\Http\Response
     */
    public function edit(CampaignInfluencerActivityStep $campaignInfluencerActivityStep)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CampaignInfluencerActivityStep  $campaignInfluencerActivityStep
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CampaignInfluencerActivityStep $campaignInfluencerActivityStep)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CampaignInfluencerActivityStep  $campaignInfluencerActivityStep
     * @return \Illuminate\Http\Response
     */
    public function destroy(CampaignInfluencerActivityStep $campaignInfluencerActivityStep)
    {
        //
    }
}
