@extends('layouts.app1')

@section('content')
    <style>
        .fs-5 {
            font-size: calc(1.275rem + .3vw) !important;
        }
    </style>
    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    @if ($message = Session::get('warning'))
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><i class="fa fa-warning ico"></i> {{ $message }}</strong>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Oh snap!</strong> {{ __('There were some problems with your input') }}.
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="container-fluid mt-5">
        <div class="container">
            <div class="text-center">
                <h1 class="fw-bold">Pricing Plans</h1>
                <p class="mt-3 fw-light">Choose the plan that's good for you and your business.</p>


            </div>


            <div class="card-group mt-3 fs-5">

                @foreach ($subpack as $subpack)
                    <div class="card bg-light ms-4">
                        <div class="card-body">
                            <?php
                            // $price = 0;
                            // $price = (($subpack->price) * ($subpack->discount) / 100);
                            ?>
                            <h3 class="card-title">{{ $subpack->title }}</h3>
                            <!-- <h5 class="">₹<del>{{ $subpack->price }}</del> / {{ $subpack->subscriptionType }}</h5> -->
                            <h5 class="">₹{{ $subpack->price }}
                                <?php
                                ?>
                                / {{ $subpack->subscriptionType }}</h5>

                            @if ($subpack->priceType != 'Free')
                            @endif
                            <!-- <p class="mt-2 fw-light h5">1 NFC Smart Card FREE. SAVE 16%</p> -->
                            <div class="text-center">
                                @if ($subpack->priceType == 'Free')
                                    <a href="register"><button type="button" class="btn btn-outline-primary btn-lg mt-2">SIGN
                                            UP
                                            FREE</button></a>
                                @else
                                    <form class="form" action="{{ route('package.payment') }}" enctype="multipart/form-data" method="post">
                                        @csrf
                                        <input type="hidden" name="amount" value="{{ $subpack->price }}">
                                        <input type="hidden" name="name" value="{{ $subpack->title }}">
                                        <button type="submit" class="btn btn-primary btn-lg mt-2">Get Started</button>
                                    </form>
                                @endif
                            </div>
                            <h6 class="card-text mt-3 h4">Best features for this Package.</h6>
                            <p class="card-text"><small class="text-muted">{{ $subpack->details }}</small></p>
                        </div>
                    </div>
                @endforeach

            </div>
        </div>

        <!-- end-->

    </div>
@endsection
