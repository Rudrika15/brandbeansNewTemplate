@extends('layouts.app')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
@section('header', 'Appliers')
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    @if ($message = Session::get('warning'))
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><i class="fa fa-warning ico"></i> {{ $message }}</strong>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Oh snap!</strong> {{ __('There were some problems with your input') }}.
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <div class="container-fluid">
        <div class="">
            <form action="{{ route('brand.influencerList') }}" method="get">
                <div class="row d-flex justify-content-center">
                    <div class="col-md-8">
                        <select name="category" class="form-control">
                            <option selected disabled>Select Category</option>
                            @foreach ($category as $cat)
                                <option value="{{ $cat->name }}" @if ($cat->name == request('category')) selected @endif>{{ $cat->name }}</option>
                            @endforeach
                        </select>
                        <button type="submit" class="btn btn-violet btn-sm mt-3">Submit</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="row ">
            @foreach ($influencer as $influencers)
                <div class="col-md-3 p-1">
                    <a href="{{ route('brand.influencerProfile') }}/{{ $influencers->id }}/{{ Auth::user()->id }}" class="text-dark">
                        <div class="card" style="width: 18rem; background-color: transparent;">
                            @if (isset($influencers->profilePhoto))
                                <img src="{{ asset('profile') }}/{{ $influencers->profilePhoto }}" height="500px" class="card-img-top " alt="...">
                            @else
                                <img src="{{ asset('asset/img/defaultPerson.jpg') }}" height="500px" class="card-img-top" alt="...">
                            @endif
                            <div class="card-body">
                                <h5 class="card-title"> {{ $influencers->name }}</h5>

                                <h5 class="card-title"> <a href="instagram.com/{{ $influencers->influencer->instagramUrl }}"> {{ $influencers->influencer->instagramUrl }}</a></h5>

                                {{-- <p class="card-text">{{ $influencers->card->about }}</p> --}}
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>

    </div>




@endsection
