<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Influencer Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>


    <style>
        .user_profile_cap {
            margin-top: 30px;
            width: 100%;
            height: auto 13;
            border: 1px solid #DDD;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            overflow: hidden;
        }

        .user_profile_cover {
            img {
                width: 100%;
                -webkit-border-top-left-radius: 5px;
                -webkit-border-top-right-radius: 5px;
                -moz-border-radius-topleft: 5px;
                -moz-border-radius-topright: 5px;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
            }

        }

        .user_profile_headline {
            padding: 10px;
            font-size: 16px;
        }

        .user_profile_headline img {
            border: 1px solid #EEEEEE;
            width: 124px;
            height: 124px;
            float: left;
            margin: -90px 10px 0 0;
            position: relative;
            z-index: 111;

            background-color: white;
        }

        #see-more-bio,
        #see-less-bio {
            color: blue;
            cursor: pointer;
            text-transform: lowercase;
        }
    </style>
</head>

<body>

    <div class="container py-5">
        <div class="user_profile_cap">

            <div class="user_profile_cover ">
                @if (isset($influencer->logo))
                    <img src="{{ asset('profile') }}/{{ $influencer->profile->logo }}" class="w-100" alt="Profile Image">
                @else
                    <img src="{{ asset('asset/img/cover.png') }}" class="w-100" alt="Profile Image">
                @endif
            </div>

        </div>
        <div class="user_profile_headline">
            @if (isset($influencer->profilePhoto))
                <img src="{{ asset('profile') }}/{{ $influencer->profile->profilePhoto }}" class="rounded-circle" alt="Profile Image">
            @else
                <img src="{{ asset('asset/img/defaultPerson.jpg') }}" class="rounded-circle" alt="Profile Image">
            @endif
            <div class="d-flex justify-content-between pt-2">
                <div class="">

                    <h2>{{ $influencer->profile->name }}</h2>
                    <h6 class=""> {{ $influencer->profile->email }}</h6>
                </div>
                <div class="">
                    <span>
                        Contact Number :
                    </span>
                    <span class="mobile-no formattedMobileNumber" data-influencer-id="{{ $influencer->id }}">
                        {{ $influencer->profile->mobileno }}
                    </span>
                </div>

            </div>
        </div>
        <div class="px-3 mt-5 py-2">
            <div class="row mx-3">
                <div class="col-md-8 border rounded-3 px-2 ">
                    <p class="bio  ">
                        {{ $influencer->about }}
                    </p>
                </div>
                <div class="col-md-4">
                    <div class="border rounded-3">
                        <h2>Category</h2>

                        {{-- <span class="badge bg-secondary rounded-pill m-2" id="category">{{ $influencer->categoryId }}</span> --}}

                        @php
                            $categories = explode(', ', $influencer->categoryId);
                        @endphp

                        @foreach ($categories as $category)
                            <span class="badge bg-secondary rounded-pill m-2" id="category">{{ $category }}</span>
                        @endforeach


                    </div>
                </div>
            </div>


        </div>



    </div>


    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            // Get the raw mobile number
            var rawMobileNumber = '{{ $influencer->mobileno }}';

            // Format the mobile number
            var formattedNumber = formatMobileNumber(rawMobileNumber);
            console.log("number", formattedNumber);
            // Update the content of the span element
            $('.formattedMobileNumber[data-influencer-id="{{ $influencer->id }}"]').text(formattedNumber);
        });

        function formatMobileNumber(number) {
            // Assuming the mobile number is 10 digits
            var formattedNumber = number.substr(2, 5) + '********' + number.substr(7, 2);
            return formattedNumber;
        }
    </script>

    <script>
        let bio = document.querySelector(".bio");
        const bioMore = document.querySelector("#see-more-bio");
        const bioLength = bio.innerText.length;

        function bioText() {
            bio.oldText = bio.innerText;

            bio.innerText = bio.innerText.substring(0, 100) + "...";
            bio.innerHTML += `<span onclick='addLength()' id='see-more-bio'>See More</span>`;
        }
        //        console.log(bio.innerText)

        bioText();

        function addLength() {
            bio.innerText = bio.oldText;
            bio.innerHTML +=
                "&nbsp;" + `<span onclick='bioText()' id='see-less-bio'>See Less</span>`;
            document.getElementById("see-less-bio").addEventListener("click", () => {
                document.getElementById("see-less-bio").style.display = "none";
            });
        }
    </script>


    <script>
        const category = {!! $influencer->categoryId !!};
        console.log(category);

        document.getElementById('category').innerHTML = category.join(' <br> ');
    </script>
</body>

</html>
