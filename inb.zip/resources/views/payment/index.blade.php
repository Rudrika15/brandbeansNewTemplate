@extends('layouts.app')

@section('header', 'Payments')
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    @if ($message = Session::get('warning'))
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><i class="fa fa-warning ico"></i> {{ $message }}</strong>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Oh snap!</strong> {{ __('There were some problems with your input') }}.
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    <div class="box-content card ">
        <!-- /.box-title -->
        <div class="" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #03ACF0; color:white;">
            <div class="">
                <h4 class="">Payment Report</h4>
            </div>
            <div class="">

            </div>
        </div>
        <!-- /.dropdown js__dropdown -->
        <div class="card-content">

            <div class="table-responsive">

                <div class="table-responsive" style="margin-top: 15px;">

                    <table class="table table-bordered table-responsive">
                        <thead>
                            <tr>
                                <th> Screenshot</th>
                                <th> User Name</th>
                                <th> Action</th>
                                <th> Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($report as $reports)
                                <tr>
                                    <td><img src="{{ asset('paymentScreenshot') }}/{{ $reports->screenshot }}" alt="image" style="height: 300px; width: 300px;"></td>
                                    <td>{{ $reports->user->name }}</td>
                                    <td>
                                        @if ($reports->status == 'Pending')
                                            <span class="badge btn-primary">{{ $reports->status }}</span>
                                        @elseif ($reports->status == 'Approved')
                                            <span class="badge btn-success">{{ $reports->status }}</span>
                                        @elseif ($reports->status == 'Rejected')
                                            <span class="badge btn-danger">{{ $reports->status }}</span>
                                        @endif
                                    </td>
                                    <td>
                                        <input type="hidden" name="userId" class="userId" value="{{ $reports->userId }}">
                                        <select name="status" id="" class="form-control statusDropdown" data-id="{{ $reports->id }}" style="width: 160px;">
                                            <option selected disabled>--select status--</option>
                                            <option value="Approved" @if ($reports->status == 'Approved') selected @endif>Approved</option>
                                            <option value="Rejected" @if ($reports->status == 'Rejected') selected @endif>Rejected</option>
                                        </select>

                                    </td>
                                </tr>
                            @endforeach

                        </tbody>
                    </table>

                </div>

            </div>

        </div>
        <!-- /.card-content -->
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <script>
        $(document).ready(function() {
            $('.statusDropdown').change(function() {
                var selectedStatus = $(this).val();
                var url = "{{ route('paymentReport.changeStatus') }}";
                var selectedId = $(this).data('id');
                var userId = $(this).prev('.userId').val();
                var csrfToken = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    url: url,
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                    data: {
                        status: selectedStatus,
                        id: selectedId,
                        userId: userId,
                    },
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Status Updated',
                            text: 'Status updated to ' + selectedStatus,
                            showCancelButton: true,
                            confirmButtonText: 'Yes',
                            cancelButtonText: 'No',
                        }).then((result) => {
                            // Reload the page after the user confirms
                            if (result.isConfirmed) {
                                window.location.reload();
                            }
                        }).then(() => {
                            // Update user table package field if status is approved
                            if (selectedStatus === 'Approved') {
                                // Make another AJAX request to update the user table
                                $.ajax({
                                    url: "{{ route('updateUserPackage') }}",
                                    method: 'POST',
                                    headers: {
                                        'X-CSRF-TOKEN': csrfToken
                                    },
                                    data: {
                                        id: selectedId,
                                        userId: userId,
                                    },
                                    success: function(response) {
                                        console.log('User package updated');
                                    },
                                    error: function(xhr, status, error) {
                                        console.error(error);
                                    }
                                });
                            }
                        });
                    },
                    error: function(xhr, status, error) {
                        // Handle any errors that occur during the AJAX request
                        console.error(error);
                    }
                });
            });
        });
    </script>

@endsection
