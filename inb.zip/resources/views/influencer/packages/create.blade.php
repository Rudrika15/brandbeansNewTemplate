@extends('layouts.app')
@section('header', 'Influencer Package')
@section('content')

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    @if ($message = Session::get('warning'))
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><i class="fa fa-warning ico"></i> {{ $message }}</strong>
        </div>
    @endif



    <div class="box-content card">
        <div class="" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #03ACF0; color:white;">
            <div class="">
                <h4 class="">Create Influencer Package</h4>
            </div>
            <div class="">
                <a href="{{ route('influencer.package.index') }}" class="btn btnback btn-sm" style="background-color: #002E6E; color:white;">BACK</a>
            </div>
        </div>
        <div class="card-content">

            <form action="{{ route('influencer.package.store') }}" enctype="multipart/form-data" class="was-validated" novalidate method="post" style="margin-top: 15px;">
                @csrf

                <div class="mb-3">
                    <label for="title" class="form-label">Title</label>

                    <select name="title" id="title" class="form-control">
                        <option selected disabled>--Select your option--</option>
                        <option value="Basic" @if (old('title') == 'Basic') selected @endif>Basic</option>
                        <option value="Standard" @if (old('title') == 'Standard') selected @endif>Standard</option>
                        <option value="Premium" @if (old('title') == 'Premium') selected @endif>Premium</option>
                    </select>
                    @if ($errors->has('title'))
                        <span class="error text-danger fs-6">{{ $errors->first('title') }}</span>
                    @endif
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="text" class="form-control" value="{{ old('price') }}" id="price" name="price" required>
                    @if ($errors->has('price'))
                        <span class="error text-danger fs-6">{{ $errors->first('price') }}</span>
                    @endif
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea type="text" class="form-control" id="tinymce" name="description" required>{{ old('description') }}</textarea>
                    @if ($errors->has('description'))
                        <span class="error text-danger fs-6">{{ $errors->first('description') }}</span>
                    @endif
                </div>


                <br>
                <button type="submit" class="btn btnback btn-sm" style="background-color: #002E6E; color:white;">Submit</button>
            </form>

        </div>
        <!-- /.card-content -->
    </div>
    <script>
        function readURL(input, tgt) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.querySelector(tgt).setAttribute("src", e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>


@endsection
