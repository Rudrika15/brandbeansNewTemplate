@extends('layouts.app')

@section('header', 'Appliers')
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    @if ($message = Session::get('warning'))
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><i class="fa fa-warning ico"></i> {{ $message }}</strong>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Oh snap!</strong> {{ __('There were some problems with your input') }}.
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    <div class="container" style="display: flex; justify-content: center">
        <div class=" row ">
            <div class="pricing-table">
                @foreach ($pricing as $pricings)
                    <div class="col col-first">
                        <div class="thead">
                            <div class="center-v">Points for</div>
                        </div>
                        @foreach ($pricings->brandPackageDetails as $foractivity)
                            @foreach ($foractivity->activity as $activity)
                                <div class="td">{{ $activity->title }}</div>
                            @endforeach
                        @endforeach
                        <div class="td"></div>

                    </div>
                    <div class="col">
                        {{-- bg-blue-2 --}}
                        <div class="thead bg-blue-1">
                            <h4>{{ $pricings->title }}</h4>


                            <span style="font-size: 20px; font-weight: 500"><span class="currency">₹</span>{{ $pricings->price }}</span><br>
                            <span style="font-size: 15px">{{ $pricings->points }} <small>Points</small></span>

                            {{-- <span style=" position: relative;width: 20px;text-align: left; font-size: 30px;">
                            </span> --}}

                        </div>
                        @foreach ($pricings->brandPackageDetails as $detail)
                            <div class="td">
                                {{-- {{ $detail->details }}- --}}
                                {{ $detail->points }}</div>
                        @endforeach
                        <form action="{{ route('pay') }}" method="post">
                            @csrf
                            <input type="hidden" name="amount" value="{{ $pricings->price }}">
                            <div class="td"><button class="btn-order js__popup_open" data-target="#register-form-popup-2">ORDER NOW</button></div>
                        </form>
                    </div>
                @endforeach
            </div>
        </div>

    </div>



@endsection
