@extends('layouts.app')
@section('header', 'Campaign')
@section('content')

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    @if ($message = Session::get('warning'))
        {{-- <a href="https://play.google.com/store/apps/details?id=com.aspireotech.brandbeans&hl=en-IN" target="_blank"> --}}
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><i class="fa fa-warning ico"></i>
                {!! $message !!}
            </strong>
        </div>
        {{-- </a> --}}
    @endif




    <div class="box-content card">
        <div class="" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #03ACF0; color:white;">
            <div class="">
                <h4 class="">Create Campaign</h4>
            </div>
            <div class="">
                <a href="{{ route('brand.campaign.index') }}" class="btn btnback btn-sm" style="background-color: #002E6E; color:white;">BACK</a>
            </div>
        </div>
        <div class="card-content">

            <form action="{{ route('brand.campaign.store') }}" enctype="multipart/form-data" class="was-validated" novalidate method="post" style="margin-top: 15px;">
                @csrf
                <div class="alert alert-warning" role="alert">
                    <span style="font-weight: 600">Note:</span> <span>Kindly note that per campaign create you spent <b>{{ $point->points }}</b> points as per your package</span>
                </div>

                <div class="mb-3">
                    <label for="title" class="form-label">Title</label><span style="color: red">*</span>
                    <input type="text" class="form-control" value="{{ old('title') }}" id="title" name="title" required>
                    @if ($errors->has('title'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('title') }}</span>
                        </span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="detail" class="form-label">Detail</label><span style="color: red">*</span>
                    <textarea name="detail" id="detail" class="form-control" required>{{ old('detail') }}</textarea>
                    @if ($errors->has('detail'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('detail') }}</span>
                        </span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Price</label><span style="color: red">*</span>
                    <input type="number" class="form-control" value="{{ old('price') }}" id="price" name="price" required>
                    @if ($errors->has('price'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('price') }}</span>
                        </span>
                    @endif
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Photo</label><span style="color: red">*</span>
                            <div class="row">
                                <div class="col-md-7">
                                    <input type="file" accept="image/*" onchange="readURL(this,'#img1')" class="form-control" id="image" name="photo" require>
                                </div>
                                <div class="col-md-5">
                                    <label for="image"></label>
                                    <img src="{{ url('asset/img/default.jpg') }}" alt="{{ __('main image') }}" id="img1" style='min-height:100px;min-width:150px;max-height:100px;max-width:150px'>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="rule" class="form-label">Rule</label>
                    <input type="text" class="form-control" id="rule" name="rule">
                </div>

                <div class="mb-3">
                    <label for="eligibleCriteria" class="form-label">Eligible Criteria</label>
                    <input type="text" class="form-control" value="{{ old('eligibleCriteria') }}" id="eligibleCriteria" name="eligibleCriteria" required>
                    @if ($errors->has('eligibleCriteria'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('eligibleCriteria') }}</span>
                        </span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="targetGender" class="form-label">Target Gender</label>

                    <select name="targetGender" value="{{ old('targetGender') }}" id="" class="form-control" required>
                        <option disabled selected>--Select your Option--</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Both">Both</option>
                    </select>
                    @if ($errors->has('targetGender'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('targetGender') }}</span>
                        </span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="targetAgeGroup" class="form-label">Target Age Group</label>
                    <div class="row">
                        <div class="col-md-3">
                            <input type="number" id="minTargetAgeGroup" class="form-control" min="0" value="{{ old('minTargetAgeGroup') }}" placeholder="minimum age group" name="minTargetAgeGroup" required>
                            @if ($errors->has('minTargetAgeGroup'))
                                <span class="invalid-feedback" role="alert">
                                    <span style="color: red">{{ $errors->first('minTargetAgeGroup') }}</span>
                                </span>
                            @endif
                        </div>
                        <div class="col-md-3">
                            <input type="number" class="form-control" id="maxTargetAgeGroup" value="{{ old('maxTargetAgeGroup') }}" placeholder="maximum age group" name="maxTargetAgeGroup" required>
                            @if ($errors->has('maxTargetAgeGroup'))
                                <span class="invalid-feedback" role="alert">
                                    <span style="color: red">{{ $errors->first('maxTargetAgeGroup') }}</span>
                                </span>
                            @endif
                        </div>
                    </div>


                </div>

                <div class="mb-3">
                    <label for="startDate" class="form-label">Start Date</label>
                    <input type="date" class="form-control" min="{{ date('Y-m-d') }}" value="{{ old('startDate') }}" id="startDate" name="startDate" required>
                    @if ($errors->has('startDate'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('startDate') }}</span>
                        </span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="endDate" class="form-label">End Date</label>
                    <input type="date" class="form-control" min="{{ date('Y-m-d') }}" value="{{ old('endDate') }}" id="endDate" name="endDate" required>
                    @if ($errors->has('endDate'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red;">{{ $errors->first('endDate') }}</span>
                        </span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="applyForLastDate" class="form-label">Apply For Last Date</label>
                    <input type="date" class="form-control" min="{{ date('Y-m-d') }}" value="{{ old('applyForLastDate') }}" id="applyForLastDate" name="applyForLastDate" required>
                    @if ($errors->has('applyForLastDate'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('applyForLastDate') }}</span>
                        </span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="task" class="form-label">Task</label>
                    <input type="text" class="form-control" value="{{ old('task') }}" id="task" name="task" required>

                </div>

                <div class="mb-3">
                    <label for="maxApplication" class="form-label">Max Application</label>
                    <input type="number" class="form-control" value="{{ old('maxApplication') }}" id="maxApplication" name="maxApplication">
                    {{-- @if ($errors->has('maxApplication'))
                        <span class="invalid-feedback" role="alert">
                            <span style="color: red">{{ $errors->first('maxApplication') }}</span>
                        </span>
                    @endif --}}
                </div>

                <br>
                <button type="submit" class="btn btnback btn-sm" style="background-color: #002E6E; color:white;">Submit</button>
            </form>

        </div>
        <!-- /.card-content -->
    </div>
    <script>
        function readURL(input, tgt) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.querySelector(tgt).setAttribute("src", e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>


@endsection
