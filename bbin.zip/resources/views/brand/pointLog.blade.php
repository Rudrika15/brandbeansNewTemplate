@extends('layouts.app')

@section('header', 'Point Logs')
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    @if ($message = Session::get('warning'))
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><i class="fa fa-warning ico"></i> {{ $message }}</strong>
        </div>
    @endif



    <div class="box-content card ">

        <div class="" style="padding: 12px 10px 12px 10px; display: flex; justify-content: space-between; background-color: #03ACF0; color:white;">
            <div class="">
                <h4 class="">{{ Auth::user()->name }}'s Point Logs</h4>
            </div>
            <div class="">
                <h4> Total Points : <i>{{ $sum }}</i></h4>
            </div>
        </div>
        <div class="card-content">
            <div class="table-responsive">


                <table id="" class="table table-bordered table-responsive">
                    <thead>
                        <tr>
                            <th> Date</th>
                            {{-- <th> Time</th> --}}
                            <th> Remarks</th>
                            <th> Points</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($brandPoints as $points)
                            <tr>
                                <td>{{ $points->created_at->format('d-m-Y') }} </td>
                                {{-- <td>{{ $points->updated_at->format('H:i') }} </td> --}}
                                <td>{{ $points->remark }} </td>
                                <td>
                                    @if ($points->points < 0)
                                        <span class="text-danger">{{ $points->points }}</span>
                                    @else
                                        <span class="text-success">{{ $points->points }}</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
                @if (!empty($brandPoints))
                    {{ $brandPoints->links() }}
                @endif
            </div>
        </div>
    </div>
    </div>


@endsection
